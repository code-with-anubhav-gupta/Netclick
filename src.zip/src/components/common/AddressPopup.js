"use client";
import { useAppContext } from "@/context/Context";
import { useEffect } from "react";
import { RxCross2 } from "react-icons/rx";

const AddressPopup = () => {
  const {
    showAddressPopup,
    setShowAddressPopup,
    serviceAddress,
    setServiceAddress,
  } = useAppContext();

  useEffect(() => {
    if (showAddressPopup) {
      document.body.style.overflow = "hidden";
      document.body.style.height = "100vh";
    } else {
      document.body.style.overflow = "";
      document.body.style.height = "";
    }

    return () => {
      document.body.style.overflow = "";
      document.body.style.height = "";
    };
  }, [showAddressPopup]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (serviceAddress.trim()) {
      setShowAddressPopup(false);
    }
  };

  if (!showAddressPopup) return null;

  return (
    <div className="fixed mt-5 inset-0 z-50 flex items-center justify-center overflow-hidden">
      <div
        className="fixed inset-0 bg-black opacity-50"
        onClick={() => setShowAddressPopup(false)}
      ></div>

      <div className="h-[30rem] max-h-[100vh] bg-white text-black rounded-lg p-6 w-full max-w-[22rem] mx-4 relative z-50 overflow-y-auto">
        <div
          className="flex justify-end items-center mb-4 cursor-pointer"
          onClick={() => setShowAddressPopup(false)}
        >
          <RxCross2 className="text-lg" />
        </div>
        <h2 className="text-2xl font-semibold mb-4">
          What is the address of the service?
        </h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Please Enter The Address"
            className="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:border-[#D9A562]"
            value={serviceAddress}
            onChange={(e) => setServiceAddress(e.target.value)}
          />
        </form>
        <div className="mt-4 bg-blue-50 p-3 rounded-lg flex items-start gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-5 w-5 text-blue-500 mt-0.5"
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
              clipRule="evenodd"
            />
          </svg>
          <p className="text-sm text-blue-800">
            This information will only be transmitted to the providers you book.
          </p>
        </div>
        <div className="flex justify-center  gap-4 mb-6">
          <button
            type="button"
            onClick={() => setShowAddressPopup(false)}
            className="px-8 py-1 bg-gray-200 text-xs text-gray-800 rounded-full hover:bg-gray-300 transition-colors"
          >
            Back
          </button>
          <button
            type="submit"
            className="px-8 py-1 bg-[#D9A562] text-xs text-white rounded-full hover:bg-[#ecc48f] transition-colors"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddressPopup;
