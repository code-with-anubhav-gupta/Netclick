"use client";
import React from "react";
import SocialMediaSidebar from "@/components/common/SocialMediaSidebar";
import NavbarLayout from "@/components/common/NavbarLayout";
import FreelanceProfileLeftLayout from "@/components/layout/FreelanceProfileLeftLayout";
import FreelanceProfileRightLayout from "@/components/layout/FreelanceProfileRightLayout";
import FooterLayout from "@/components/common/FooterLayout";
import { useAppContext } from "@/context/Context";

export default function ProfilePage() {
  const { showAddressPopup } = useAppContext();

  return (
    <div className="min-h-screen bg-white">
      <div
        className={`${
          showAddressPopup ? "blur-sm" : ""
        } transition-all duration-200`}
      >
        {/* Header/Navigation */}
        <NavbarLayout />

        {/* Add padding to account for fixed header */}
        <div className="pt-10">
          <main className="max-w-6xl mx-auto px-4 py-8">
            {/* Profile Section */}
            <div className="flex flex-col md:flex-row gap-8">
              {/* Left Side - Profile Image & Actions */}
              <FreelanceProfileLeftLayout />

              {/* Right Side - Profile Information */}
              <FreelanceProfileRightLayout />
            </div>
          </main>
        </div>

        {/* Footer */}
        <FooterLayout />

        {/* Social Media Sidebar */}
        <SocialMediaSidebar />
      </div>
    </div>
  );
}
